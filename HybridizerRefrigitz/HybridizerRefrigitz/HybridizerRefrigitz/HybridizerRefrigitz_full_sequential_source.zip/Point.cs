//
//www.IranProject.Ir
//
namespace HybridizerRefrigitz
{
	public class Point
	{
		public Point()
		{
			x=0;
			y=0;
		}
		public Point(int i,int j)
		{
			x=i;
			y=j;
		}
		public int x;
		public int y;
	}
}